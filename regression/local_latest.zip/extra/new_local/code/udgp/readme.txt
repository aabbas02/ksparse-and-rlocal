This folder contains the code to reproduce the results of the udgp simulations (fig. 3d).
