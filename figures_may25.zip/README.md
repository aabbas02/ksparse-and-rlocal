# A Stochastic EM approach for Shuffled Regression

This repository contains code for the methods described in the paper, "Stochastic Expectation-Maximization for Shuffled Linear Regression" by Abid et al., which appeared in the 2018 Allerton Conference.
