ax = gca;
exportgraphics(ax,'rLocal_NoLev.pdf','Resolution',300) 
r